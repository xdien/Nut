#include "querybase_p.h"

QueryBase::QueryBase(QObject *parent) : QObject(parent)
{

}
