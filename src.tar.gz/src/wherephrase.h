/**************************************************************************
**
** This file is part of Nut project.
** https://github.com/HamedMasafi/Nut
**
** Nut is free software: you can redistribute it and/or modify
** it under the terms of the GNU Lesser General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** Nut is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU Lesser General Public License for more details.
**
** You should have received a copy of the GNU Lesser General Public License
** along with Nut.  If not, see <http://www.gnu.org/licenses/>.
**
**************************************************************************/

#ifndef PHRASE_H
#define PHRASE_H

#include <QtCore/qglobal.h>

#include <QVariant>

QT_BEGIN_NAMESPACE

class SqlGeneratorBase;
struct PhraseData{
    enum Condition
    {
        Equal,
        Less,
        Greater,
        Null,
        In,

        NotEqual,
        LessEqual,
        GreaterEqual,
        NotNull,
        NotIn,

        And,
        Or,
        Like,

        Not,

        Add,
        Minus,
        Multiple,
        Divide
    };

    enum Type{
        Field,
        WithVariant,
        WithOther
    };
    Type type;

    Condition operatorCond;

    QString text;
    const PhraseData *left;
    const PhraseData *right;
    QVariant operand;

    PhraseData(const char *className, const char* s){
        text = QString(className) + "." + s;
        type = Field;
    }

    PhraseData(PhraseData *l, Condition o, const PhraseData *r) : left(l), right(r){
        operatorCond = o;
    }

    PhraseData(PhraseData *l, Condition o, QVariant r) : left(l), operand(r){
        operatorCond = o;
    }
};

class FieldPhrase{
    enum Type{
        Field,
        WithVariant,
        WithOther
    };
    Type type;

    QString text;
    const FieldPhrase *left;
    const FieldPhrase *right;
    QVariant operand;

public:
    enum Condition
    {
        Equal,
        Less,
        Greater,
        Null,
        In,

        NotEqual,
        LessEqual,
        GreaterEqual,
        NotNull,
        NotIn,

        And,
        Or,
        Like,

        Not,

        Add,
        Minus,
        Multiple,
        Divide
    };

    Condition operatorCond;


    FieldPhrase(const char *className, const char* s);
//    FieldPhrase(QString s);
    FieldPhrase(FieldPhrase *l, Condition o, const FieldPhrase *r);
    FieldPhrase(FieldPhrase *l, Condition o, QVariant r);

    PhraseData *data;
    FieldPhrase(PhraseData *l, PhraseData::Condition o, PhraseData *r);

    ~FieldPhrase();

    QString operatorString() const;

    QString command(SqlGeneratorBase *generator) const;

    QString escapeVariant(const QVariant &var) const;

    FieldPhrase operator ==(const FieldPhrase &other);
    FieldPhrase operator !=(const FieldPhrase &other);
    FieldPhrase operator <(const FieldPhrase &other);
    FieldPhrase operator >(const FieldPhrase &other);
    FieldPhrase operator <=(const FieldPhrase &other);
    FieldPhrase operator >=(const FieldPhrase &other);

    FieldPhrase operator +(const FieldPhrase &other);
    FieldPhrase operator -(const FieldPhrase &other);
    FieldPhrase operator *(const FieldPhrase &other);
    FieldPhrase operator /(const FieldPhrase &other);

    FieldPhrase operator &&(const FieldPhrase &other);
    FieldPhrase operator ||(const FieldPhrase &other);

    FieldPhrase operator !();

    FieldPhrase operator ==(const QVariant &other);
    FieldPhrase operator !=(const QVariant &other);
    FieldPhrase operator <(const QVariant &other);
    FieldPhrase operator >(const QVariant &other);
    FieldPhrase operator <=(const QVariant &other);
    FieldPhrase operator >=(const QVariant &other);

    FieldPhrase isNull();
    FieldPhrase in(QVariantList list);
    FieldPhrase in(QStringList list);
    FieldPhrase like(QString pattern);
};

QT_END_NAMESPACE

#endif // PHRASE_H
