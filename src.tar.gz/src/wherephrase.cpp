/**************************************************************************
**
** This file is part of Nut project.
** https://github.com/HamedMasafi/Nut
**
** Nut is free software: you can redistribute it and/or modify
** it under the terms of the GNU Lesser General Public License as published by
** the Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** Nut is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU Lesser General Public License for more details.
**
** You should have received a copy of the GNU Lesser General Public License
** along with Nut.  If not, see <http://www.gnu.org/licenses/>.
**
**************************************************************************/

#include <QDataStream>
#include <QDate>
#include <QDateTime>
#include <QDebug>
#include <QTime>

#include "wherephrase.h"

QT_BEGIN_NAMESPACE

FieldPhrase::FieldPhrase(const char *className, const char *s)
{
    data = new PhraseData(className, s);
    text = QString(className) + "." + s;
    type = Field;
}

FieldPhrase::FieldPhrase(FieldPhrase *l, Condition o, const FieldPhrase *r) : left(l), right(r)
{
    operatorCond = o;

    qDebug() << "ctor" << operatorString();
    type = WithOther;
}

FieldPhrase::FieldPhrase(FieldPhrase *l, Condition o, QVariant r) : left(l)//, operand(r)
{
    operand = //QVariant(r.type(), r.data());
    qVariantFromValue(r);
//    __t = r.type();
//    __d = r.data();

//    QDataStream ds(&data, QIODevice::WriteOnly);
//    ds << operand;

//    operandCStr = escapeVariant(operand).toLatin1().data();
    operatorCond = o;
    qDebug() << "ctor2" << operatorString() << escapeVariant(operand);
    type = WithVariant;
}

FieldPhrase::FieldPhrase(PhraseData *l, PhraseData::Condition o, PhraseData *r)
{
    data = new PhraseData(l, o, r);
}

FieldPhrase::~FieldPhrase()
{
    qDebug() << "detor" << operatorString() << escapeVariant(operand);
}


QString FieldPhrase::operatorString() const
{
    switch (operatorCond){
    case Equal:
        return "=";
    case NotEqual:
        return "!=";
    case Less:
        return "<";
    case Greater:
        return ">";
    case LessEqual:
        return "<=";
    case GreaterEqual:
        return ">=";
    case Null:
        return "IS NULL";
    case In:
        return "IN";
    case And:
        return "AND";
    case Or:
        return "OR";
    case Not:
        return "NOT";
    case Like:
        return "LIKE";

    case Add:
        return "+";
    case Minus:
        return "-";
    case Multiple:
        return "*";
    case Divide:
        return "/";
    }

    return QString();
}

QString FieldPhrase::command(SqlGeneratorBase *generator) const
{
    switch(type){
    case Field:
        return text;

    case WithVariant:
        qDebug() << "ch" << operatorString() << operand;
        return "(" + left->command(generator) + " " + operatorString() + " " + escapeVariant(operand) + ")";

    case WithOther:
        qDebug() << "ch" << operatorString();
        return "(" + left->command(generator) + " " + operatorString() + " " + right->command(generator) + ")";
    }
}

QString FieldPhrase::escapeVariant(const QVariant &var) const
{
    switch (operand.type()) {
    case QVariant::Int:
    case QVariant::Double:
        return operand.toString();
        break;

    case QVariant::String:
        return "'" + operand.toString() + "'";

    case QVariant::DateTime:
        return "'" + operand.toDateTime().toString() + "'";

    case QVariant::Date:
        return "'" + operand.toDate().toString() + "'";

    case QVariant::Time:
        return "'" + operand.toTime().toString() + "'";

    case QVariant::StringList:
    case QVariant::List:
        return "['" + operand.toStringList().join("', '") + "']";

    case QVariant::Invalid:
        return "<FAIL>";

    default:
        return "";
    }
}

FieldPhrase FieldPhrase::operator ==(const FieldPhrase &other){
    return FieldPhrase(this, Equal, &other);
}

FieldPhrase FieldPhrase::operator !=(const FieldPhrase &other){
    return FieldPhrase(this, NotEqual, &other);
}

FieldPhrase FieldPhrase::operator <(const FieldPhrase &other){
    return FieldPhrase(this, Less, &other);
}

FieldPhrase FieldPhrase::operator >(const FieldPhrase &other){
    qDebug() << "oth";
    return FieldPhrase(this, Greater, &other);
}

FieldPhrase FieldPhrase::operator <=(const FieldPhrase &other){
    return FieldPhrase(this, LessEqual, &other);
}

FieldPhrase FieldPhrase::operator >=(const FieldPhrase &other){
    return FieldPhrase(this, GreaterEqual, &other);
}

FieldPhrase FieldPhrase::operator +(const FieldPhrase &other){
    return FieldPhrase(this, Add, &other);
}

FieldPhrase FieldPhrase::operator -(const FieldPhrase &other){
    return FieldPhrase(this, Minus, &other);
}

FieldPhrase FieldPhrase::operator *(const FieldPhrase &other){
    return FieldPhrase(this, Multiple, &other);
}

FieldPhrase FieldPhrase::operator /(const FieldPhrase &other){
    return FieldPhrase(this, Divide, &other);
}

FieldPhrase FieldPhrase::operator &&(const FieldPhrase &other){
    return FieldPhrase(this, And, &other);
}

FieldPhrase FieldPhrase::operator ||(const FieldPhrase &other){
    return FieldPhrase(this, Or, &other);
}

FieldPhrase FieldPhrase::operator !(){
    QString ntext = text
            .replace("IS NULL", "IS NOT NULL");

//    return FieldPhrase(ntext);
}

FieldPhrase FieldPhrase::operator ==(const QVariant &other){
    return FieldPhrase(this, Equal, other);
}

FieldPhrase FieldPhrase::operator !=(const QVariant &other){
    return FieldPhrase(this, NotEqual, other);
}

FieldPhrase FieldPhrase::operator <(const QVariant &other){
    return FieldPhrase(this, Less, other);
}

FieldPhrase FieldPhrase::operator >(const QVariant &other){
    qDebug() << "var";
    return FieldPhrase(this, Greater, other);
}

FieldPhrase FieldPhrase::operator <=(const QVariant &other){
    return FieldPhrase(this, LessEqual, other);
}

FieldPhrase FieldPhrase::operator >=(const QVariant &other){
    return FieldPhrase(this, GreaterEqual, other);
}

FieldPhrase FieldPhrase::isNull(){
//    return FieldPhrase(text + " IS NULL");
}

FieldPhrase FieldPhrase::in(QVariantList list)
{
    return FieldPhrase(this, In, list);
}

FieldPhrase FieldPhrase::in(QStringList list)
{
    return FieldPhrase(this, In, list);
}

FieldPhrase FieldPhrase::like(QString pattern)
{
    return FieldPhrase(this, Like, pattern);
}

QT_END_NAMESPACE

