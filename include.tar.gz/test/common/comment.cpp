#include "comment.h"

Comment::Comment(QObject *parent) : Table(parent)
{

}
